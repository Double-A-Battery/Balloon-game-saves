import SwiftUI

func RandomNum() -> CGFloat{
    return CGFloat(Int.random(in:-100...200))
}

struct ContentView: View {
    @State var timeCount = 0.0
    @State var pause = false
    @State var randx1:CGFloat = RandomNum()
    @State var randy1:CGFloat = RandomNum()
    @State var Counter = 0
    let timer = Timer.publish(every: 0.01, on: .main, in: .common).autoconnect()
    var body: some View {
        ZStack{
            Image("Area")
                .resizable()
        VStack {
            Text("\(timeCount, specifier: "%.2f")")
                .onReceive(timer) { _ in
                    if pause == true{
                    if (timeCount < 10){
                        timeCount += 0.01
                        print(timeCount)
                    }}
                    else{
                        timeCount = 0
                        pause = false
                    }
            Button {
                if timeCount == 0{
                    pause = true
                }
                if(timeCount<10){
                print("button was tapped")
                randx1 = RandomNum()
                randy1 = RandomNum()
                Counter += 1}
            } label: {
                Image("Balloon")
                    .resizable()
                    .frame(width:50, height: 60)}
                    
            .offset(x: randx1, y: randy1)
                    
                    Text("score:")
                    Text(String(Counter))
            
                    
        }
        }
    }
}
}
